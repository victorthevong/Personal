package editor;

public class Print {

	public static boolean print = false;

	public static void printLine(String toprint) {

		if (print) {
			System.out.println(toprint);
		}
	}





}
